import os

# Create empty array
folder = list()

# FilePath to read txt file
path = "file/"

# FileName to read
txtFile = "DataRaw.txt"

# If the folder doesn't exist, the script will print error message and exit.
if not (os.path.exists(path) and os.path.isdir(path)):
    print("Error: Folder that you want to find txt file in does not appear to exist.")
    exit()

# Read file with error exception
try:
    # The following statement doesn't need to close the file. This clause automatically close the file.
    with open(path + txtFile, "r") as txtfile:
        # Read lines from txt file
        for line in txtfile:
            # Replace "\n" to ""
            name = line.replace("\n", "")
            # Check whether folder named as variable name doesn't exist.
            if not os.path.exists(name):
                # Create the directory with certain name
                os.mkdir(name)
except IOError:
    # If the file doent's exist, the script will print error message and exit.
    print("Error: Text file you want to read does not appear to exist.")
        